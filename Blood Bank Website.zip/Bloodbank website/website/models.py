from datetime import timezone
from enum import unique
from . import db 
from flask_login import UserMixin

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(50), unique=True)
    password = db.Column(db.String(50))
    full_Name = db.Column(db.String(50))
    gender = db.Column(db.String(50))
    birth_Date = db.Column(db.DateTime(timezone=True))
    phone_Number = db.Column(db.String(50))
